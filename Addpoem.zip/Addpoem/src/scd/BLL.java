package scd;

public class BLL {
    private DAO dao;

    public BLL() {
        dao = new DAO();
    }

    public void handleSavePoemClick(String addTitle, String misra1, String misra2) {
        dao.addPoem(addTitle, misra1, misra2);
    }
    
    public void handleListBooksClick() {
        dao.getBookList();
    }
}