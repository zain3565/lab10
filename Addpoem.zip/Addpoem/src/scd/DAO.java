package scd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//Existing import statements...

public class DAO {
 private Connection connection;
 private String jdbcUrl = "jdbc:mysql://localhost:3306/f200308?useSSL=false";
 private String username = "root";
 private String password = "";

 public DAO() {
     try {
         connection = DriverManager.getConnection(jdbcUrl, username, password);
         if (connection != null) {
             System.out.println("Connected to Database");
         }
     } catch (SQLException e) {
         System.err.println("Connection error: " + e.getMessage());
     }
 }

 public void addPoem(String addTitle, String misra1, String misra2) {
     try {
         String sql = "INSERT INTO addpoem (title, misra1, misra2) VALUES (?, ?, ?)";
         PreparedStatement statement = connection.prepareStatement(sql);
         statement.setString(1, addTitle);
         statement.setString(2, misra1);
         statement.setString(3, misra2);
         statement.executeUpdate();


     } catch (SQLException e) {
         System.err.println("Error adding poem: " + e.getMessage());
     }
 }

    public String[] getBookList() {
        List<String> bookList = new ArrayList<>();
        try {
            String sql = "SELECT title FROM addpoem";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                bookList.add(resultSet.getString("title"));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving book list: " + e.getMessage());
        }

        return bookList.toArray(new String[0]);
    }
}