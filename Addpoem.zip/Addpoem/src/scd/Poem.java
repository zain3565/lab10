package scd;

import java.awt.*;
import java.awt.event.*;

public class Poem {
    private BLL bll;
    private Frame frame;
    private Panel listBooksPanel;
    private Panel addPoemPanel;
    private TextField addTitleField;
    private TextField misra1TextField;
    private TextField misra2TextField;
    private Button saveButton;

    public Poem() {
        bll = new BLL();
    }

    public void createAndShowGUI() {
        frame = new Frame("Poem");
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

        Button listBooksButton = new Button("List of Books");
        Button addPoemButton = new Button("Add Poem");
        addTitleField = new TextField(20);
        Label addTitleLabel = new Label("Add Title:");
        misra1TextField = new TextField(20);
        Label misra1Label = new Label("Misra 1:");
        misra2TextField = new TextField(20);
        Label misra2Label = new Label("Misra 2:");
        saveButton = new Button("Save Poem");

        listBooksPanel = new Panel();
        listBooksPanel.setLayout(new FlowLayout());
        listBooksPanel.add(listBooksButton);

        addPoemPanel = new Panel();
        addPoemPanel.setLayout(new GridLayout(6, 2));
        addPoemPanel.add(addTitleLabel);
        addPoemPanel.add(addTitleField);
        addPoemPanel.add(misra1Label);
        addPoemPanel.add(misra1TextField);
        addPoemPanel.add(misra2Label);
        addPoemPanel.add(misra2TextField);
        addPoemPanel.add(addPoemButton);

        listBooksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.remove(listBooksPanel);
                frame.add(addPoemPanel);
                frame.revalidate();
                frame.repaint();
            }
        });

        addPoemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPoemPanel.add(saveButton);
                frame.revalidate();
                frame.repaint();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String addTitle = addTitleField.getText();
                String misra1 = misra1TextField.getText();
                String misra2 = misra2TextField.getText();
                bll.handleSavePoemClick(addTitle, misra1, misra2);
                addTitleField.setText("");
                misra1TextField.setText("");
                misra2TextField.setText("");
            }
        });

        frame.setLayout(new FlowLayout());
        frame.add(listBooksPanel);
        frame.setSize(400, 250);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        Poem app = new Poem();
        app.createAndShowGUI();
    }
}