-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2023 at 06:02 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `f200308`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpoem`
--

CREATE TABLE `addpoem` (
  `title` varchar(100) NOT NULL,
  `misra1` text NOT NULL,
  `misra2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addpoem`
--

INSERT INTO `addpoem` (`title`, `misra1`, `misra2`) VALUES
('HIHIHI', 'fgj', 'asfj'),
('kjhjvv', 'nk', 'cf'),
('ali', 'usman', 'talha'),
('', '', ''),
('wf', 'wf', 'fw'),
('', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `poem`
--

CREATE TABLE `poem` (
  `ID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `poem`
--

INSERT INTO `poem` (`ID`, `Title`) VALUES
(1, 'ِ ضَرْبٍ فِيهِ تَوْهِينٌ ... وَتَخْضِيعُ وإقْرَانُ'),
(2, ' قال بَلْعاءُ بن قيس الكنانيّ');

-- --------------------------------------------------------

--
-- Table structure for table `verses`
--

CREATE TABLE `verses` (
  `Verse ID` int(20) NOT NULL,
  `Misra 1` varchar(1000) NOT NULL,
  `Misra 2` varchar(1000) NOT NULL,
  `Poem ID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `poem`
--
ALTER TABLE `poem`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `verses`
--
ALTER TABLE `verses`
  ADD PRIMARY KEY (`Verse ID`),
  ADD KEY `Foreign key` (`Poem ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `poem`
--
ALTER TABLE `poem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `verses`
--
ALTER TABLE `verses`
  MODIFY `Verse ID` int(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `verses`
--
ALTER TABLE `verses`
  ADD CONSTRAINT `Foreign key` FOREIGN KEY (`Poem ID`) REFERENCES `poem` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
